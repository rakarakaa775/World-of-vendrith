# Database

Documentation-first database design.

## Current

- `TABLE_SPECIFICATION_v0.1.md`

## Rule

No SQL migration is generated until the complete table specification passes schema audit.
