# Vandrith World — Core Repository

**Land of Fate**

This repository is documentation-first and Canon-first.

## Start here

- `CORE/VANDRITH_CORE.md` — master project core
- `DATABASE/TABLE_SPECIFICATION_v0.1.md` — current database specification

## Dependency

```text
WORLD BIBLE
    ↓
DOMAIN MODEL
    ↓
DATABASE BLUEPRINT
    ↓
TABLE SPECIFICATION
    ↓
SCHEMA AUDIT
    ↓
SQL / SUPABASE
    ↓
SIMULATOR DATA
```

Implementation must not redefine Canon.
