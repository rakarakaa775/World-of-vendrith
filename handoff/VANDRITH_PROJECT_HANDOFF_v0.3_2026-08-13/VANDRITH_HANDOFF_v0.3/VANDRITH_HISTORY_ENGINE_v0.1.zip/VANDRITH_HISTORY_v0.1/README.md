# Vandrith History Engine v0.1

Documentation-first specification for hierarchical historical simulation.

## Main file

`HISTORY/HISTORY_ENGINE_SPECIFICATION_v0.1.md`

## Rule

One canonical event may affect multiple history scopes. Do not duplicate the event merely to represent its broader impact.
