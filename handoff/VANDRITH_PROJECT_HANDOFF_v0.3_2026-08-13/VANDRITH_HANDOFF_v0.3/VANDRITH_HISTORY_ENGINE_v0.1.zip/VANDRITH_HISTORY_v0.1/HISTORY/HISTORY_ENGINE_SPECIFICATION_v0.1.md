# Vandrith History Engine — Specification v0.1

**Status:** `DRAFT — READY FOR REVIEW`

## 1. Core Principle

Vandrith uses **one History Engine**, not separate unrelated history systems.

One canonical historical event may affect multiple scopes:

```text
Personal
Settlement
Regional
Kingdom
Civilization
World
```

An event only appears at a higher scope when its significance and impact justify it.

## 2. History Hierarchy

```text
HISTORY ENGINE
├── Personal History
├── Settlement / Village History
├── State / Regional History
├── Kingdom History
├── Civilization History
└── World History
```

| Scope | Purpose |
|---|---|
| Personal | Individual life events |
| Settlement | Events important to a village/town/city |
| Regional | Events affecting a region/state |
| Kingdom | Events affecting a major polity |
| Civilization | Events affecting civilization continuity, culture, technology, identity, or institutions |
| World | Events with world-scale consequences |

## 3. One Event, Multiple Scopes

Do not duplicate the same event merely because it has multiple impacts.

Example:

```text
Event #1842
"The Gold Rush of Crescent Moon"

Primary scope:
Settlement

Affected scopes:
Settlement
Region
Kingdom
```

The event remains one canonical event. Higher-level history views are projections of its impact.

## 4. `history_events`

| Column | Type | Description |
|---|---|---|
| `id` | uuid | PK |
| `world_id` | uuid | FK → worlds |
| `event_type` | text | Event category |
| `title` | text | Historical title |
| `description` | text | Description |
| `primary_scope` | text | personal/settlement/regional/kingdom/civilization/world |
| `significance` | numeric | Historical importance |
| `occurred_at_simulation_time` | timestamptz | Simulation time |
| `created_by_system` | text | Source domain |
| `cause_event_id` | uuid | Optional preceding event |
| `status` | text | active/revised/archived |
| `metadata` | jsonb | Additional data |
| `created_at` | timestamptz | DB audit |

## 5. `history_event_scopes`

Maps one event to every affected scope.

| Column | Type |
|---|---|
| `id` | uuid |
| `history_event_id` | uuid |
| `scope_type` | text |
| `scope_entity_id` | uuid |
| `impact_level` | numeric |
| `visibility` | text |
| `summary` | text |

Example:

```text
Gold Rush
├── Crescent Moon Village    impact 100
├── Region                   impact 70
└── Kingdom                  impact 30
```

## 6. Significance vs Impact

**Significance** = how historically important the event is overall.

**Impact** = how strongly the event affects a particular scope.

Example:

```text
Village founder dies

Significance = 30
Village Impact = 90
Kingdom Impact = 0
World Impact = 0
```

A kingdom-wide religious revolution may have high Kingdom and Civilization impact while still having different local impacts.

## 7. Promotion Rules

Suggested v0.1 thresholds:

```text
Settlement:   impact >= 40
Regional:     impact >= 50
Kingdom:      impact >= 60
Civilization: impact >= 70
World:        impact >= 80 AND significance >= 80
```

These are simulation parameters and may be tuned after testing.

## 8. Causal History

Events may form causal chains:

```text
Gold discovered
      ↓
Mining expands
      ↓
Merchants arrive
      ↓
Population increases
      ↓
Village grows
      ↓
Kingdom establishes mining tax
```

Use `cause_event_id` to preserve causality.

## 9. Consequence Events

Do not rewrite the original event.

```text
Event #100
Gold discovered

Event #108
Mining expansion

Event #121
Trader migration

Event #145
Regional trade route established
```

## 10. Personal History

Examples:

```text
birth
education
employment
marriage
child birth
migration
major achievement
death
```

Routine activities such as breakfast should remain activity history, not historical events.

## 11. Settlement / Village History

Examples:

```text
founding
new building
tavern opens
mine discovered
major fire
population milestone
important visitor
new teacher arrives
local religious change
major economic change
```

## 12. Regional History

Examples:

```text
trade route opens
regional famine
migration wave
major infrastructure project
regional conflict
administrative reform
major resource discovery
```

## 13. Kingdom History

Examples:

```text
king crowned
succession crisis
law enacted
war declared
territory annexed
tax reform
religious reform
major rebellion
government restructuring
```

## 14. Civilization History

Examples:

```text
language transformation
major migration
religious transformation
technology breakthrough
cultural synthesis
civilizational collapse
civilizational revival
new writing system
major institutional change
```

A civilization may continue through political regime changes.

## 15. World History

World History is intentionally selective.

Examples:

```text
continent-scale war
world-changing Legacy discovered
major civilization collapse
global religious transformation
catastrophic natural event
world-changing technology
major inter-civilization migration
```

Zero World History events during Year 1 is valid.

## 16. Legacy Integration

History and Legacy are related but distinct:

```text
HISTORY EVENT
      │
      ├── immediate consequences
      ├── long-term consequences
      └── may create LEGACY
```

Legacy preserves important creations, discoveries, institutions, artifacts, places, traditions, and other enduring effects.

## 17. Example Legacy

```text
Legacy:
"The Crescent Gold Mine"

Created:
Year 1

Original purpose:
Resource extraction

Immediate effects:
- Increased village wealth
- Increased mining employment

Long-term effects:
- Migration
- Trade expansion
- Political interest

Major events:
- Crescent Gold Rush
- Mining Tax Reform

Current status:
Active
```

The people who created a Legacy may die while the Legacy continues.

## 18. History vs Activity Log

```text
Activity History
= what happened during simulation execution

Historical Event
= what matters historically
```

Example:

```text
Alden ate breakfast
→ Activity History

Alden founded the village school
→ Historical Event

The school transformed regional education
→ Regional / Kingdom / Civilization consequence
```

## 19. History vs World Bible

```text
WORLD BIBLE
= predefined Canon

SIMULATION
= what happens

HISTORY ENGINE
= records what happened

WORLD HISTORY
= selected historically significant simulation events
```

Simulation must not silently rewrite Canon.

## 20. Church of Light Example

A political transformation can naturally climb the hierarchy:

```text
Church gains influence
      ↓
Settlement impact
      ↓
Kingdom political reform
      ↓
Civilization religious transformation
      ↓
Possible World History event
```

The promotion is caused by actual consequences, not by a hard-coded assumption that every religious event is world-changing.

## 21. One-Year Validation

Expected scale for the first simulation year:

```text
Personal:
hundreds/thousands of small life events

Settlement:
dozens of meaningful events

Regional:
few meaningful events

Kingdom:
very few events

Civilization:
possibly 0–2 events

World:
possibly 0 events
```

The simulator must not manufacture epic history merely to populate the history page.

## 22. Architecture

```text
                    HISTORY ENGINE
                          │
                    HISTORY EVENT
                          │
             ┌────────────┼────────────┐
             │            │            │
          CAUSES       IMPACTS     CONSEQUENCES
                          │
             ┌────────────┼────────────┐
             │            │            │
        Settlement     Regional     Kingdom
             │                         │
             └──────── Civilization ───┘
                          │
                        World
                          │
                       Legacy
```

## Decision

**History Architecture v0.1: APPROVED FOR DATABASE DESIGN**

The system uses one History Engine with six scopes:

**Personal → Settlement → Regional → Kingdom → Civilization → World.**

The architecture is designed to support the first one-year simulation while remaining valid for much longer simulations.
